package readDoc;

import java.io.IOException;
import java.util.Map;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class ConstantInfo {
	
	public static final String client_id="isv_GLS_SAVTEST";
	public static final String client_secret = "q4tJitvaaM142S94aeAPMXX96kN45fkEO7b2sCe5V2j61ghheWXluUtSTS29nQx0";
	public static final String grant_type = "client_credentials";
	public static final String tenant_id = "a29c193a-7b4d-11eb-9852-0638767d04b5";
	public static final OkHttpClient client = new OkHttpClient().newBuilder().build();
	public static String access_token;
	public static final String access_token_url = "https://connect.visma.com/connect/token";


	
	// GetEmployeeInfo Constant data
	public static final String jobIdForEmp_url = "https://api.analytics1.hrm.visma.net/v1/command/nl/hrm/employees";
	public static final String employeeFileUris_url = "https://api.analytics1.hrm.visma.net/v1/query/nl/hrm/employees";
	
	//	GetContractsInfo.java
	public static final String jobIdForContract_url = "https://api.analytics1.hrm.visma.net/v1/command/nl/hrm/contracts";
	public static final String contractFileUris_url = "https://api.analytics1.hrm.visma.net/v1/query/nl/hrm/contracts";
	
	//Fixed data 
	public static final String Company_code = "NL02";
	public static final String Location_Code = "1000 Amsterdam";
	public static final String Country_Name = "Netherlands";
	public static final String Country_Code = "NL";
	public static final String Street = "Proostwetrring 40";
	public static final String City = "Utrecht";
	public static final String Zip_Code = "3542AG";
	public static final String State_Name = "Dummy";
	public static final String Locatio_Name = "Dummy";
	public static final String Employee_Status = "calculate based on end date";
	public static final String Employee_Category = "Dummy";
	
	
	
	
//public static String getAccessToken() throws Exception {
	
		static {
		String credentials = String.format("client_id=%s&client_secret=%s&grant_type=%s&tenant_id=%s", client_id, client_secret, grant_type, tenant_id);
		MediaType mediaType = MediaType.parse("application/x-www-form-urlencoded");
		RequestBody body = RequestBody.create(mediaType, credentials);
		Request request = new Request.Builder()
		  .url(access_token_url)
		  .method("POST", body)
		  .addHeader("Content-Type", "application/x-www-form-urlencoded")
		  .build();
		Response response = null;
		try {
			response = client.newCall(request).execute();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		ObjectMapper mapper = new ObjectMapper();
		Map<String, String> userData = null;
		try {
			userData = mapper.readValue(  
					response.body().string(), new TypeReference<Map<String, String>>() {  
			});
		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
		access_token = userData.get("access_token");	
//		return access_token;
	}

	
	
	
	
	
	

}
