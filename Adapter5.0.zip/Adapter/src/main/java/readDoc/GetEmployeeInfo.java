package readDoc;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.json.CDL;
import org.json.JSONArray;
import org.json.JSONObject;

import com.fasterxml.jackson.core.type.TypeReference;  

import com.fasterxml.jackson.databind.ObjectMapper;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class GetEmployeeInfo {
	static long timeToSleep = 4L;
    static TimeUnit time = TimeUnit.SECONDS;
    
	
	public static String getJobIdForEmp() throws Exception {
		
		MediaType mediaType = MediaType.parse("application/json");
		RequestBody body = RequestBody.create(mediaType, "");
		Request request = new Request.Builder()
		  .url(ConstantInfo.jobIdForEmp_url)
		  .method("POST", body)
		  .addHeader("Authorization", "Bearer "+ConstantInfo.access_token)
		  .build();
		Response response = ConstantInfo.client.newCall(request).execute();	

		ObjectMapper mapper = new ObjectMapper();
		Map<String, String> userData = mapper.readValue(  
				response.body().string(), new TypeReference<Map<String, String>>() {  
        });
			
		String jobId = userData.get("jobId");	
		
		return jobId;
	}
	
	public String getEmployeeFileUris() throws Exception {
		
		String jobId = GetEmployeeInfo.getJobIdForEmp();
		time.sleep(timeToSleep);
		MediaType mediaType = MediaType.parse("text/plain");
		RequestBody body = RequestBody.create(mediaType, "");
		Request request = new Request.Builder()
		  .url(String.format("%s/%s",ConstantInfo.employeeFileUris_url, jobId))
		  .method("GET", null)
		  .addHeader("Authorization", String.format("Bearer%s%s"," ",ConstantInfo.access_token))
		  .build();
		Response response = ConstantInfo.client.newCall(request).execute();
		
		String S=response.body().string();
		JSONObject jsonObject = new JSONObject(S);
	    JSONArray jarray=(JSONArray) jsonObject.get("employeeFileUris");
	    String employeeFileUris = (String) jarray.get(0);
		return employeeFileUris;
	}
	
	public JSONArray getEmployeeFile(String employeeFileUris) throws Exception {
		
		Request request = new Request.Builder()
		  .url(String.format("%s", employeeFileUris))
		  .method("GET", null)
		  .build();
		Response response = ConstantInfo.client.newCall(request).execute();
		String res=response.body().string();
		res=res.replace("'t", "t");
		JSONArray jsonArray = CDL.toJSONArray(res);
	    return jsonArray;
		
	}
	
}
