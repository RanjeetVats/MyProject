package readDoc;

import java.io.File;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.json.JSONArray;
import org.json.JSONObject;

public class Main {
	
	

	public static void main(String[] args) throws Exception {
		
		GetEmployeeInfo getEmployeeInfo = new GetEmployeeInfo();
		GetContractsInfo getContractsInfo = new GetContractsInfo();
		
		String employeeFileUris = getEmployeeInfo.getEmployeeFileUris();
		JSONArray employeeFile = getEmployeeInfo.getEmployeeFile(employeeFileUris);
		
		String contractFileUris = getContractsInfo.getContractFileUris();
		JSONArray contractFile = getContractsInfo.getContractFile(contractFileUris);


		for(int i =0; i<employeeFile.length(); i++) {
			JSONObject objEmpDetails = (JSONObject) employeeFile.get(i);
			JSONObject objContractDetails = getContractsInfo.getInfo((String) objEmpDetails.get("employeeid"), contractFile);
			if(objContractDetails!=null) {
				JSONObject jsonObject = new JSONObject();
				
				// employeeFile data
				jsonObject.put("EmployeeId", objEmpDetails.get("employeeid"));
				jsonObject.put("CompanyName", objEmpDetails.get("companyname"));
				jsonObject.put("IsManager", objEmpDetails.get("ismanager"));
				jsonObject.put("FirstName", objEmpDetails.get("firstname"));
				jsonObject.put("NickName", objEmpDetails.get("nickname"));
				jsonObject.put("PrefixBirthName", objEmpDetails.get("prefixbirthname"));
				jsonObject.put("BirthName", objEmpDetails.get("birthname"));
				jsonObject.put("FormattedName", objEmpDetails.get("formattedname"));
				jsonObject.put("CUSTOMPROPERTY11", objEmpDetails.get("nickname"));
				jsonObject.put("DisplayName", ConstantInfo.getDisplayName(objEmpDetails.get("nickname"), ConstantInfo.getLastName(objEmpDetails)));
	
	
	
				// contractFile data
				jsonObject.put("StartDate", ConstantInfo.changeDateFormat(objContractDetails.get("startdate")));
				jsonObject.put("EndDate", ConstantInfo.changeDateFormat(ConstantInfo.getEndDate(objContractDetails.get("enddate"))));
				jsonObject.put("FunctionalName", objContractDetails.get("functionname"));
				jsonObject.put("ExtDepartmentName", objContractDetails.get("extdepartmentname"));
				jsonObject.put("ExtDepartmentID", objContractDetails.get("extdepartmentid"));
				jsonObject.put("EmployeeTypeName", objContractDetails.get("emptypename"));
				jsonObject.put("CostCenter", objContractDetails.get("costcenter"));
				
				//Fixed data 
				jsonObject.put("Company_code", ConstantInfo.Company_code);
				jsonObject.put("Location_Code", ConstantInfo.Location_Code);
				jsonObject.put("Country_Name", ConstantInfo.Country_Name);
				jsonObject.put("Country_Code", ConstantInfo.Country_Code);
				jsonObject.put("Street", ConstantInfo.Street);
				jsonObject.put("City", ConstantInfo.City);
				jsonObject.put("Zip_Code", ConstantInfo.Zip_Code);
				jsonObject.put("State_Name", ConstantInfo.State_Name);
				jsonObject.put("Locatio_Name", ConstantInfo.Locatio_Name);
				jsonObject.put("Employee_Status", ConstantInfo.Employee_Status);
				jsonObject.put("Employee_Category", ConstantInfo.Employee_Category);
				jsonObject.put("Status", ConstantInfo.getStatus(ConstantInfo.getEndDate(objContractDetails.get("enddate"))));
	
			
				System.out.println(jsonObject.toString(4));
	

			}	
		}
		
		
	}

}
