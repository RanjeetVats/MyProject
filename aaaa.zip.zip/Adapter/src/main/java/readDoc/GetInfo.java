package readDoc;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import org.json.CDL;
import org.json.JSONArray;
import org.json.JSONObject;

import com.fasterxml.jackson.core.type.TypeReference;  

import com.fasterxml.jackson.databind.ObjectMapper;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class GetInfo {
	public static final String client_id="isv_GLS_SAVTEST";
	public static final String client_secret = "q4tJitvaaM142S94aeAPMXX96kN45fkEO7b2sCe5V2j61ghheWXluUtSTS29nQx0";
	public static final String grant_type = "client_credentials";
	public static final String tenant_id = "a29c193a-7b4d-11eb-9852-0638767d04b5";
	public static final String access_token_url = "https://connect.visma.com/connect/token";
	public static final String getEmployeeFileUris_url = "https://api.analytics1.hrm.visma.net/v1/query/nl/hrm/employees/";
//	public static final String url

	public String getAccessToken() throws Exception {
		
		String credentials = String.format("client_id=%s&client_secret=%s&grant_type=%s&tenant_id=%s", client_id, client_secret, grant_type, tenant_id);

		OkHttpClient client = new OkHttpClient().newBuilder()
				  .build();
				MediaType mediaType = MediaType.parse("application/x-www-form-urlencoded");
				RequestBody body = RequestBody.create(mediaType, credentials);
				Request request = new Request.Builder()
				  .url(access_token_url)
				  .method("POST", body)
				  .addHeader("Content-Type", "application/x-www-form-urlencoded")
				  .build();
				Response response = client.newCall(request).execute();
				
				ObjectMapper mapper = new ObjectMapper();
				Map<String, String> userData = mapper.readValue(  
						response.body().string(), new TypeReference<Map<String, String>>() {  
	            });
				
		String access_token = userData.get("access_token");
		
		
		return access_token;
	}
	
	public String getJobId(String access_token) throws Exception {
				
		OkHttpClient client = new OkHttpClient().newBuilder()
				  .build();
				MediaType mediaType = MediaType.parse("application/json");
				RequestBody body = RequestBody.create(mediaType, "");
				Request request = new Request.Builder()
				  .url("https://api.analytics1.hrm.visma.net/v1/command/nl/hrm/employees/")
				  .method("POST", body)
				  .addHeader("Authorization", "Bearer "+access_token)
				  .build();
				Response response = client.newCall(request).execute();
				
		
				ObjectMapper mapper = new ObjectMapper();
				Map<String, String> userData = mapper.readValue(  
						response.body().string(), new TypeReference<Map<String, String>>() {  
	            });
				
		String jobId = userData.get("jobId");
		
		
		return jobId;
	}
	
	public String getEmployeeFileUris() throws Exception {
		
		GetInfo getInfo = new GetInfo();

		String access_token = getInfo.getAccessToken();
		String jobId = getInfo.getJobId(access_token);
		
		OkHttpClient client = new OkHttpClient().newBuilder()
				  .build();
				MediaType mediaType = MediaType.parse("text/plain");
				RequestBody body = RequestBody.create(mediaType, "");
				Request request = new Request.Builder()
				  .url(String.format("https://api.analytics1.hrm.visma.net/v1/query/nl/hrm/employees/%s", jobId))
				  .method("GET", null)
				  .addHeader("Authorization", String.format("Bearer%s%s"," ",getInfo.getAccessToken()))
				  .build();
				Response response = client.newCall(request).execute();
				
				String S=response.body().string();
				JSONObject jsonObject = new JSONObject(S);
    		    JSONArray jarray=(JSONArray) jsonObject.get("employeeFileUris");
    		    String employeeFileUris = (String) jarray.get(0);
				return employeeFileUris;
	}
	
	public JSONArray getEmployeeFile(String employeeFileUris) throws Exception {
		
		OkHttpClient client = new OkHttpClient().newBuilder()
				  .build();
				Request request = new Request.Builder()
				  .url(String.format("%s", employeeFileUris))
				  .method("GET", null)
				  .build();
				Response response = client.newCall(request).execute();
				String res=response.body().string();
				JSONArray jsonArray = CDL.toJSONArray(res);
//				System.out.println(jsonArray.toString(4));
				
				try {
			         FileWriter file = new FileWriter("C:\\Codebase\\Adapter/emp.json");
			         file.write(jsonArray.toString());
			         file.close();
			      } catch (IOException e) {
			         e.printStackTrace();
			      }
				

    		    return jsonArray;
		
	}

}
