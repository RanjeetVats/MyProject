//package readDoc;
//
//public class EmployeeFileUris {
//	String changeTimestampBefore = null;
//	
//	String  employeeFileUris = null;
//	
//	String status = null;
//
//	public String getChangeTimestampBefore() {
//		return changeTimestampBefore;
//	}
//
//	public void setChangeTimestampBefore(String changeTimestampBefore) {
//		this.changeTimestampBefore = changeTimestampBefore;
//	}
//
//	public String getEmployeeFileUris() {
//		return employeeFileUris;
//	}
//
//	public void setEmployeeFileUris(String employeeFileUris) {
//		this.employeeFileUris = employeeFileUris;
//	}
//
//	public String getStatus() {
//		return status;
//	}
//
//	public void setStatus(String status) {
//		this.status = status;
//	}
//
//}
