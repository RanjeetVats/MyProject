package readDoc;

import java.io.File;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

public class Main {
	
	public static String employeeFileUris;

	public static void main(String[] args) throws Exception {
		GetInfo getInfo = new GetInfo();

		employeeFileUris = getInfo.getEmployeeFileUris();
		JSONArray res = getInfo.getEmployeeFile(employeeFileUris);
		
		// filter value

		for(int i =0; i<res.length(); i++) {
			JSONObject obj = (JSONObject) res.get(i);
			JSONObject jsonObject = new JSONObject();
			
			jsonObject.put("employeeid", obj.get("employeeid"));
			jsonObject.put("nationality", obj.get("nationality"));
			jsonObject.put("firstname", obj.get("firstname"));
			jsonObject.put("gender", obj.get("gender"));
			jsonObject.put("homecountry", obj.get("homecountry"));
			
			System.out.println(jsonObject.toString(4));
			
		}
		
	}

}
