package readDoc;

import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.json.CDL;
import org.json.JSONArray;
import org.json.JSONObject;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class GetContractsInfo {
 
	static long timeToSleep = 4L;
    static TimeUnit time = TimeUnit.SECONDS;
	
	public static String getJobIdForContract() throws Exception {
		MediaType mediaType = MediaType.parse("application/json");
		RequestBody body = RequestBody.create(mediaType, "");
		Request request = new Request.Builder()
		  .url(ConstantInfo.jobIdForContract_url)
		  .method("POST", body)
		  .addHeader("Authorization", "Bearer "+ConstantInfo.access_token)
		  .build();
		Response response = ConstantInfo.client.newCall(request).execute();
		
		ObjectMapper mapper = new ObjectMapper();
		Map<String, String> userData = mapper.readValue(  
				response.body().string(), new TypeReference<Map<String, String>>() {  
        });
			
		String jobId = userData.get("jobId");	
		
		return jobId;		
	}
	
	public String getContractFileUris() throws Exception {
		
		String jobId = GetContractsInfo.getJobIdForContract();
		time.sleep(timeToSleep);
		MediaType mediaType = MediaType.parse("text/plain");
		RequestBody body = RequestBody.create(mediaType, "");
		Request request = new Request.Builder()
		  .url(String.format("%s/%s",ConstantInfo.contractFileUris_url, jobId))
		  .method("GET", null)
		  .addHeader("Authorization", String.format("Bearer%s%s"," ",ConstantInfo.access_token))
		  .build();
		Response response = ConstantInfo.client.newCall(request).execute();
		
		String S=response.body().string();
		JSONObject jsonObject = new JSONObject(S);
	    JSONArray jarray=(JSONArray) jsonObject.get("contractFileUris");
	    String contractFileUris = (String) jarray.get(0);
		return contractFileUris;
	}
	
	public JSONArray getContractFile(String contractFileUris ) throws Exception {
		
		Request request = new Request.Builder()
		  .url(String.format("%s", contractFileUris))
		  .method("GET", null)
		  .build();
		Response response = ConstantInfo.client.newCall(request).execute();
		String res=response.body().string();
		JSONArray jsonArray = CDL.toJSONArray(res);

	    return jsonArray;
		
	}
	
	
	public JSONObject getInfo(String employeeid,JSONArray contractFile) throws Exception {
		JSONObject finalJsonObject = new JSONObject();
		SimpleDateFormat sdfo = new SimpleDateFormat("yyyy-MM-dd");   
		Date EndDate = sdfo.parse("0000-00-00");   
		for(int i =0; i<contractFile.length(); i++) {
			JSONObject jsonObject = (JSONObject) contractFile.get(i);
			if(employeeid.equals(jsonObject.get("employeeid"))) {
				finalJsonObject = jsonObject;
				if((Object)jsonObject.get("enddate") != null && (Object)jsonObject.get("enddate") != "" && (Object)jsonObject.get("enddate") != " ") {
					if(EndDate.before(sdfo.parse((String) jsonObject.get("enddate")))){
						EndDate = sdfo.parse((String) jsonObject.get("enddate"));
						finalJsonObject = jsonObject;

					}
				}
				
			}
			
		}
		
		return finalJsonObject;


	}



}
